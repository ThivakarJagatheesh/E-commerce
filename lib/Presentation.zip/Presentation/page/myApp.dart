import 'package:flutter/material.dart';
import 'package:scanner/Presentation/page/college_login/collage_login_page.dart';

class MyApp extends StatelessWidget {
  const MyApp({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CollageLoginPage(),
    );
  }
}