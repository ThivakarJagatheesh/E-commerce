import 'package:flutter/material.dart';

import 'package:qr_code_scanner/qr_code_scanner.dart';
import 'package:scanner/Presentation/page/scan/scan_document.dart';

class MobileScannerPage extends StatefulWidget {
  const MobileScannerPage({Key? key}) : super(key: key);

  @override
  State<MobileScannerPage> createState() => _MobileScannerPageState();
}

class _MobileScannerPageState extends State<MobileScannerPage> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  late QRViewController controller;
  String? qrText;
  String? scanqrText;
  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(children: <Widget>[
        Expanded(
          flex: 4,
          child: QRView(
            key: qrKey,
            onQRViewCreated: _onQRViewCreated,
            formatsAllowed: [
              BarcodeFormat.aztec,
              BarcodeFormat.codabar,
              BarcodeFormat.code128,
              BarcodeFormat.qrcode,
              BarcodeFormat.maxicode
            ],
            overlay: QrScannerOverlayShape(
              borderColor: Colors.red,
              borderRadius: 10,
              borderLength: 30,
              borderWidth: 10,
              cutOutSize: 300,
            ),
          ),
        ),
      ]),
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    controller.scannedDataStream.listen((scanData) {
      //setState(() {
      if (scanData.code == "") {
        debugPrint(scanData.format.formatName);
      } else {
        controller.stopCamera();
        showPrintedMessage("Successfully Scanned", scanData.code);
      }
      //_scan();
      // });
    });
  }

  showPrintedMessage(String title, String msg) {
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
              title: Text(title),
              content: Text(msg),
              actions: [
                TextButton(
                    onPressed: () {
                      Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (c) => MyAppForm()),
                          (route) => false);
                    },
                    child: Text("ok"))
              ],
            ));
  }
}
