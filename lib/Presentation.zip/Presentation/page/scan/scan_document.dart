import 'dart:io';
import 'dart:typed_data';

import 'package:advance_pdf_viewer/advance_pdf_viewer.dart';
import 'package:document_scanner_flutter/configs/configs.dart';
import 'package:document_scanner_flutter/document_scanner_flutter.dart';
import 'package:flutter/material.dart';

import 'package:image_picker/image_picker.dart';
import 'package:scanner/Presentation/page/scan/pdf.dart';
import 'package:scanner/Presentation/page/scan/qr_scanner_page.dart';
import 'package:flutter_native_image/flutter_native_image.dart';
//import 'package:edge_detection/edge_detection.dart';

class MyAppForm extends StatefulWidget {
  const MyAppForm({Key? key}) : super(key: key);
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyAppForm> {
  final picker = ImagePicker();
  PDFDocument? _scannedDocument;
  File? _scannedImage;
  List<File>? _imageFile = [];
  int index = 0;
  double mb = 0.0;
  // ignore: unused_field
  File? _scannedDocumentFile;
  openPdfScanner(BuildContext context) async {
    var doc = await DocumentScannerFlutter.launchForPdf(
      context,
      labelsConfig: {
        ScannerLabelsConfig.ANDROID_NEXT_BUTTON_LABEL: "Next Steps",
        ScannerLabelsConfig.PDF_GALLERY_FILLED_TITLE_SINGLE: "Only 1 Page",
        ScannerLabelsConfig.PDF_GALLERY_FILLED_TITLE_MULTIPLE:
            "Only {PAGES_COUNT} Page"
      },
      //source: ScannerFileSource.CAMERA
    );
    if (doc != null) {
      _scannedDocument = null;
      setState(() {});
      await Future.delayed(Duration(milliseconds: 100));
      _scannedDocumentFile = doc;
      _scannedDocument = await PDFDocument.fromFile(doc);
      _imageFile!.add(doc);
      setState(() {});
    }
  }

  List<Uint8List> imagesss = [];
  String qrcode = 'Unknown';
  bool delete = false;
  bool selectImage = false;
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Document Scanner'),
      ),
      body: _scannedDocument != null || _scannedImage != null
          ? Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
              // appBar.preferredSize.height,
              child: CustomScrollView(
                primary: false,
                slivers: <Widget>[
                  SliverPadding(
                    padding: const EdgeInsets.all(3.0),
                    sliver: SliverGrid.count(
                        childAspectRatio: 0.8,
                        mainAxisSpacing: 1, //horizontal space
                        crossAxisSpacing: 1, //vertical space
                        crossAxisCount: 3, //number of images for a row
                        children: _imageFile!
                            .map((image) => Container(
                                  height: 200,
                                  width: 100,
                                  child: Stack(
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.stretch,
                                        children: [
                                          GestureDetector(
                                            onTap: () => openViewer(image),
                                            onLongPress: () {},
                                            child: Image.file(
                                              image,
                                              height: 100,
                                              width: MediaQuery.of(context)
                                                      .size
                                                      .width /
                                                  3,
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                          Container(
                                            height: 25,
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width /
                                                3,
                                            decoration: BoxDecoration(
                                                color: Colors.white),
                                            child: Text(
                                              image.path,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          )
                                        ],
                                      ),
                                      Positioned(
                                          right: 5,
                                          top: 5,
                                          child: GestureDetector(
                                            onTap: () => _removeFile(_imageFile!
                                                .map((e) => e.path)
                                                .toList()
                                                .indexOf(image.path)),
                                            child: Container(
                                              padding: EdgeInsets.all(3),
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  border: Border.all(
                                                      width: 1,
                                                      color: Colors.grey),
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          15)),
                                              child: Icon(Icons.delete,
                                                  size: 20, color: Colors.red),
                                            ),
                                          ))
                                    ],
                                  ),
                                ))
                            .toList()),
                  ),
                ],
              ),
            )
          /*Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
             if (_scannedDocument != null || _scannedImage != null) ...[
              if (_scannedImage != null)
              
                Image.file(_scannedImage!,
                    width: 300, height: 300, fit: BoxFit.contain),
              // if (_scannedDocument != null)
                Expanded(
                    child: PDFViewer(
                  document: _scannedDocument!,
                )),
              // Padding(
              //   padding: const EdgeInsets.all(8.0),
              //   child: Text(
              //       _scannedDocumentFile?.path ?? _scannedImage?.path ?? ''),
              // ),
            ],
            
            // Center(
            //   child: Builder(builder: (context) {
            //     return ElevatedButton(
            //         onPressed: () => openPdfScanner(context),
            //         child: Text("PDF Scan"));
            //   }),
            // ),
            // Center(
            //   child: Builder(builder: (context) {
            //     return ElevatedButton(
            //         onPressed: () => openImageScanner(context),
            //         child: Text("Image Scan"));
            //   }),
            // )
          ],
        )*/
          : Center(
              child: Text('No Image Scanner Yet....'),
            ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: index,
        onTap: (value) {
          setState(() {
            index = value;
            navigatePage(value);
          });
        },
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.qr_code), label: "QR Code"),
          BottomNavigationBarItem(
              icon: Icon(Icons.document_scanner), label: "Scan"),
          BottomNavigationBarItem(
              icon: Icon(Icons.file_copy), label: "Export PDF"),
        ],
      ),
    );
  }

  navigatePage(int index) {
    switch (index) {
      case 0:
        Navigator.push(
            context, MaterialPageRoute(builder: (c) => MobileScannerPage()));
        break;
      case 1:
        openImageScanner(context);
        //openPdfScanner(context);

        break;
      case 2:
      if(_imageFile!.length<=40){
        Navigator.push(context,
            MaterialPageRoute(builder: (c) => Firstpage(image: _imageFile!)));}
            else{
              showPrintedMessage("Warning", "Image Limit Exceed(only 40 image)");
            }
        break;
      default:
    }
  }

  openImageScanner(BuildContext context) async {
    var image = await DocumentScannerFlutter.launch(context,
       //source: ScannerFileSource.CAMERA,
        labelsConfig: {
          ScannerLabelsConfig.ANDROID_NEXT_BUTTON_LABEL: "Next Step",
          ScannerLabelsConfig.ANDROID_OK_LABEL: "OK"
        });
    if (image != null) {
      _scannedImage = image;
  final compressImage = await compressFile(image);
      _imageFile!.add(compressImage);
      final bytes = compressImage.readAsBytesSync().lengthInBytes;
      final kb = bytes / 1024;
       mb = kb / 1024;
      print(mb);
      // for (var unit8Lists in _imageFile!) {
      //   imagesss.add(unit8Lists.readAsBytesSync());

      // }
      setState(() {});
    }
  }

  Future<File> compressFile(File file) async {
    File compressedFile = await FlutterNativeImage.compressImage(
      file.path,
      quality: 20,
    );
    return compressedFile;
  }

  openViewer(File currentItem) {
    // int index =
    //     _imageFile!.map((e) => e.path).toList().indexOf(currentItem.path);

    // Navigator.push(
    //     context,
    //     MaterialPageRoute(
    //         builder: (_) =>
    //             PhotoViewer(galleryItems: _imageFile, selectedItemIndex: index)));
  }

  _removeFile(index) {
    if (index <= _imageFile!.length - 1) {
      setState(() {
        _imageFile!.removeAt(index);
      });
    }
  }
  showPrintedMessage(String title, String msg) {
    showDialog(
        context: context,
        builder: (context) => AlertDialog(
              title: Text(title),
              content: Text(msg),
              actions: [
                TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text("ok"))
              ],
            ));
  }
}
