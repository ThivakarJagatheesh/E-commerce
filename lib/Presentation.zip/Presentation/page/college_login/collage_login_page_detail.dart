import 'package:flutter/material.dart';
import 'package:scanner/Presentation/page/login/login_page.dart';

class CollageLoginPageDetail extends StatefulWidget {
  const CollageLoginPageDetail({Key? key}) : super(key: key);

  @override
  State<CollageLoginPageDetail> createState() => _CollageLoginPageDetailState();
}

class _CollageLoginPageDetailState extends State<CollageLoginPageDetail> {
  final collageCodeController = TextEditingController();
  final _key = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Center(
        child: SingleChildScrollView(
          physics: NeverScrollableScrollPhysics(),
          child: Form(
            key: _key,
            child: Stack(
              fit: StackFit.loose,
              overflow: Overflow.visible,
              children: [
                Stack(
                  fit: StackFit.loose,
                  overflow: Overflow.visible,
                  //mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 400,
                      margin: EdgeInsets.all(6),
                      alignment: Alignment.center,
                      child: Card(
                        elevation: 5,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 70,
                            ),
                            FlutterLogo(
                              size: 44,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Text('ExamCentre'),
                            SizedBox(
                              height: 40,
                            ),
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 20),
                              child: TextFormField(
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Cannot Empty';
                                  }
                                  return null;
                                },
                                controller: collageCodeController,
                                onFieldSubmitted: (value) {
                                  if (_key.currentState!.validate()) {}
                                },
                                decoration: InputDecoration(
                                    prefixIcon: Icon(Icons.book),
                                    labelText: 'Enter college Code',
                                    labelStyle:
                                        TextStyle(fontStyle: FontStyle.italic),
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(8))),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 170,
                      bottom: -30,
                      child: Card(
                        shadowColor: Colors.grey,
                        elevation: 6,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(80),
                          //set border radius more than 50% of height and width to make circle
                        ),
                        child: Container(
                          height: 80,
                          width: 80,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              boxShadow: [BoxShadow(blurRadius: 5.0)],
                              // borderRadius: BorderRadius.circular(80),),
                              shape: BoxShape.circle),
                          child: InkWell(
                            onTap: () {
                              if (_key.currentState!.validate()) {
                                var route = MaterialPageRoute(builder: (context)=>LoginPage());
                                Navigator.push(context, route);
                              }
                            },
                            child: Container(
                              margin: EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                  color: Colors.indigoAccent,
                                  shape: BoxShape.circle),
                              child: Icon(
                                Icons.arrow_forward,
                                color: Colors.white,
                                size: 40,
                              ),
                              // onPressed: () {},
                              //  ),
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
                Positioned(right: 20, bottom: -180, child: Text('Version 3.0'))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
