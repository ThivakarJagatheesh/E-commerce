import 'package:flutter/material.dart';
import 'package:scanner/Presentation/page/college_login/collage_login_page_detail.dart';

class CollageLoginPage extends StatelessWidget {
  const CollageLoginPage({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Colors.blue,Colors.white])),
      child: CollageLoginPageDetail(),
    );
  }
}